import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface IdentitasKantor {
  id: number;
  kantor: string;
  deskripsi: string;
  alamat: string;
  foto_kantor: string;
  gmaps: string;
  kategori: string;
}

@Injectable({
  providedIn: 'root'
})
export class IdentitasKantorService {

  private apiUrl = 'http://localhost:3000/identitaskantor';  // URL server API

  constructor(private http: HttpClient) {}

  getIdentitasKantor(): Observable<IdentitasKantor[]> {
    return this.http.get<IdentitasKantor[]>(this.apiUrl);
  }
}
