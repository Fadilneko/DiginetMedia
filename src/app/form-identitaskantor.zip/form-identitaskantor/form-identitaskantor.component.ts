  import { Component, Inject } from '@angular/core';
  import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { PopupKonfirmasiComponent } from '../popup-konfirmasi/popup-konfirmasi.component';

  @Component({
    selector: 'app-form-identitaskantor',
    templateUrl: './form-identitaskantor.component.html',
    styleUrls: ['./form-identitaskantor.component.css']
  })
  export class FormIdentitaskantorComponent {
    isEditMode: boolean;
    form: FormGroup;

    constructor(
      public dialogRef: MatDialogRef<FormIdentitaskantorComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any,
      private fb: FormBuilder,
      public dialog: MatDialog
    ) {
      this.isEditMode = data.isEditMode;
      this.form = this.fb.group({
        no: [data.element?.no || null],
        kantor: [data.element?.kantor || '', Validators.required],
        logo: [data.element?.logo || ''],
        deskripsi: [data.element?.deskripsi || ''],
        alamat: [data.element?.alamat || ''],
        fotoKantor: [data.element?.fotoKantor || ''],
        gmapsImage: [data.element?.gmapsImage || ''],
        kategori: [data.element?.kategori || '']
      });
    }

    
  onSave() {
    if (this.form) {
      // Buka dialog konfirmasi
      const dialogRef = this.dialog.open(PopupKonfirmasiComponent, {
        width: '500px',
        height: '165px',
        data: { isEditMode: this.isEditMode }
      });
      

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          // Jika pengguna menekan "Ya", data dikirim kembali
          this.dialogRef.close(this.form.value);  // Kirim data kembali ke komponen pemanggil
        }
      });
    }
  }

    onCancel(): void {
      this.dialogRef.close();
    }
    
  }
